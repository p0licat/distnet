#TODO: script interface for checking /proc/net/tcp

#TODO: generalize file parser libraries (inheritance?) for other system files ...logging/network mampping
