#!/usr/bin/python

from distnet.main import main

main()
