#!/bin/bash
python distnet/main.py 
