Visualizer for TCP connections. Ports 53 and 43 are used by some features.
