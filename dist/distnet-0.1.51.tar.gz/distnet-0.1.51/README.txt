Visualizer for TCP connections.

Installation:
    pip3 install +git http://github.com/

Usage:
    python -m distnet -h
